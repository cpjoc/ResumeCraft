<?php
session_start();
include __DIR__ . '/connect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $password = $_POST["password"];

    // Check for empty fields
    if (empty($email) || empty($password)) {
        echo "<script>alert('Please fill in both email and password.'); window.history.back();</script>";
        exit;
    }

    // Get user by email
    $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // If email found
    if ($stmt->num_rows === 1) {
        $stmt->bind_result($id, $name, $hashedPassword);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashedPassword)) {
            // Save session
            $_SESSION['user_id'] = $id;
            $_SESSION['user_name'] = $name;

            echo "<script>alert('Login successful!'); window.location.href='../dashboard.php';</script>";
            exit;
        } else {
            echo "<script>alert('Incorrect password.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Email not found.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
