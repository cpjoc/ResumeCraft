<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"]);
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm_password"];

    // Basic empty check
    if (empty($name) || empty($email) || empty($password) || empty($confirmPassword)) {
        echo "<script>alert('Please fill in all fields.'); window.history.back();</script>";
        exit;
    }

    // ✅ Validate name (letters, spaces, min 2 characters)
    if (!preg_match("/^[a-zA-Z\s]{2,}$/", $name)) {
        echo "<script>alert('Please enter a valid name (letters and spaces only, min 2 characters).'); window.history.back();</script>";
        exit;
    }

    // ✅ Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Please enter a valid email address.'); window.history.back();</script>";
        exit;
    }

    // ✅ Check if passwords match
    if ($password !== $confirmPassword) {
        echo "<script>alert('Passwords do not match!'); window.history.back();</script>";
        exit;
    }

    // ✅ Check if email already exists
    $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        echo "<script>alert('Email already registered. Please login.'); window.location.href='../login.php';</script>";
        exit;
    }

    // ✅ Insert user
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $insertStmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $insertStmt->bind_param("sss", $name, $email, $hashedPassword);

    if ($insertStmt->execute()) {
        echo "<script>alert('Registration successful! Please login.'); window.location.href='../login.php';</script>";
    } else {
        echo "<script>alert('Something went wrong. Try again later.'); window.history.back();</script>";
    }

    $checkStmt->close();
    $insertStmt->close();
    $conn->close();
}
?>
