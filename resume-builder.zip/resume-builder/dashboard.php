<?php
session_start();
include 'php/connect.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: php/login.php");
  exit;
}

$user_id = $_SESSION['user_id'];

// Get all resumes for the logged-in user
$stmt = $conn->prepare("SELECT * FROM resumes WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>

<head>
  <title>Resume Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

  <!-- TOP NAVBAR -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Resume Builder</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link btn btn-outline-light" href="php/logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Dashboard content -->
  <div class="container mt-5">
    <h2>Your Resume Dashboard</h2>

    <!-- Create a new resume link -->
    <a href="edit-resume.php" class="btn btn-success mb-3">+ Create New Resume</a>

    <!-- List of resumes -->
    <?php if ($result->num_rows > 0): ?>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Full Name</th>
            <th>Profession</th>
            <th>Last Updated</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($resume = $result->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($resume['full_name']) ?></td>
              <td><?= htmlspecialchars($resume['profession']) ?></td>
              <td><?= $resume['updated_at'] ?></td>
              <td>
                <!-- View resume -->
                <a href="view-resume.php?resume_id=<?= $resume['resume_id'] ?>" class="btn btn-primary btn-sm" title="View Resume">👁️ View</a>
                <!-- Edit resume -->
                <a href="edit-resume.php?resume_id=<?= $resume['resume_id'] ?>" class="btn btn-warning btn-sm" title="Edit Resume">✏️ Edit</a>
                <!-- Delete resume -->
                <a href="delete-resume.php?resume_id=<?= $resume['resume_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this resume?');">🗑️ Delete</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>No resumes found. Create your first resume.</p>
    <?php endif; ?>

  </div>

</body>

</html>

<?php
$stmt->close();
$conn->close();
?>
