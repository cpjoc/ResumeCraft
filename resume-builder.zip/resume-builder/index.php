<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ResumeCraft - Create, Edit, and Share Your Resume</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
    <header class="bg-dark py-3">
        <nav class="container d-flex justify-content-between align-items-center">
            <div class="logo text-white">
                <h1>ResumeCraft</h1>
            </div>
            <div class="nav-links">
                <ul class="list-unstyled d-flex mb-0">
                    <li class="ms-3"><a href="index.php" class="text-white text-decoration-none">Home</a></li>
                    <li class="ms-3"><a href="login.php" class="text-white text-decoration-none">Login</a></li>
                    <li class="ms-3"><a href="signup.php" class="text-white text-decoration-none">Sign Up</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <section class="hero bg-primary text-white text-center py-5">
        <div class="container">
            <h2 class="display-4">Create a Professional Resume in Minutes</h2>
            <p class="lead">With ResumeCraft, you can easily build, edit, and share your resume. Whether you're a job seeker or professional, we've got you covered.</p>
            <a href="signup.php" class="btn btn-light btn-lg">Get Started</a>
        </div>
    </section>

    <section class="features py-5 bg-light text-center">
        <div class="container">
            <h2 class="mb-5">Features</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="feature-card p-4 bg-white shadow-sm rounded">
                        <i class="fas fa-pencil-alt fa-3x text-primary mb-3"></i>
                        <h3>Create Your Resume</h3>
                        <p>Start with a template or create your resume from scratch with our easy-to-use editor.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-card p-4 bg-white shadow-sm rounded">
                        <i class="fas fa-clone fa-3x text-primary mb-3"></i>
                        <h3>Clone & Edit Resumes</h3>
                        <p>Easily duplicate and edit your resumes. Perfect for customizing your resumes for different jobs.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-card p-4 bg-white shadow-sm rounded">
                        <i class="fas fa-share-alt fa-3x text-primary mb-3"></i>
                        <h3>Share & Download</h3>
                        <p>Share your resume via a unique link or download it as a PDF to print or email.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="testimonial py-5 bg-light text-center">
        <div class="container">
            <h2 class="mb-5"></h2>
            <div class="row">
                <div class="col-md-6 mb-4">
                    
                </div>
                <div class="col-md-6 mb-4">
                    
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-white text-center py-3">
       
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
