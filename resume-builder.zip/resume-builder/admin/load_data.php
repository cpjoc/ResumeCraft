<?php
include '../php/connect.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action === 'resumes') {
    // Query to fetch all resumes
    $res = $conn->query("SELECT * FROM resumes");

    if ($res->num_rows > 0) {
        echo "<h3>All Resumes</h3><table class='table table-bordered'>
                <thead>
                    <tr>
                        <th>Resume ID</th>
                        <th>User ID</th>
                        <th>Full Name</th>
                        <th>Profession</th>
                        <th>Updated At</th>
                    </tr>
                </thead>
                <tbody>";

        while ($row = $res->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['resume_id']}</td>
                    <td>{$row['user_id']}</td>
                    <td>{$row['full_name']}</td>
                    <td>{$row['profession']}</td>
                    <td>{$row['updated_at']}</td>
                  </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<div class='alert alert-warning'>No resumes found.</div>";
    }
} elseif ($action === 'users') {
    // Query to fetch all users
    $res = $conn->query("SELECT * FROM users");

    if ($res->num_rows > 0) {
        echo "<h3>All Users</h3><table class='table table-bordered'>
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>";

        while ($row = $res->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['email']}</td>
                    <td>
                        <button class='btn btn-danger' onclick='deleteUser({$row['id']})'>Delete</button>
                    </td>
                  </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<div class='alert alert-warning'>No users found.</div>";
    }
}
?>
