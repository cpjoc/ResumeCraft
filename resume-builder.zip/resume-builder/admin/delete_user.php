<?php
include '../php/connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = isset($_POST['id']) ? $_POST['id'] : null;

    if ($user_id) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        
        if ($stmt->execute()) {
            echo "User deleted successfully!";
        } else {
            echo "Failed to delete user.";
        }
    } else {
        echo "Invalid user ID.";
    }
}
?>
