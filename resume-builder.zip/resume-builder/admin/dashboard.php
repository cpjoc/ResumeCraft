<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <div class="d-flex ms-auto">
                <span class="navbar-text me-3">
                    Logged in as <strong><?php echo $_SESSION['admin_username'] ?? 'Admin'; ?></strong>
                </span>
                <a class="btn btn-outline-danger" href="logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <h2 class="mb-4">Welcome to Admin Dashboard</h2>

        <!-- Dashboard Buttons -->
        <div class="mb-3">
            <button class="btn btn-primary me-2" onclick="loadData('users')">View All Users</button>
            <button class="btn btn-secondary" onclick="loadData('resumes')">View All Resumes</button>
        </div>

        <!-- AJAX Content -->
        <div id="dashboard-content" class="mt-3"></div>
    </div>

    <!-- JavaScript for AJAX -->
    <script>
    function loadData(type) {
        const content = document.getElementById("dashboard-content");
        content.innerHTML = "<div class='alert alert-info'>Loading...</div>";

        const sanitizedType = encodeURIComponent(type);
        fetch("load_data.php?action=" + sanitizedType)
            .then(res => res.text())
            .then(data => {
                content.innerHTML = data;
            })
            .catch(error => {
                content.innerHTML = "<div class='alert alert-danger'>Error loading data.</div>";
                console.error(error);
            });
    }

    function deleteUser(userId) {
        if (confirm("Are you sure you want to delete this user?")) {
            fetch("delete_user.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "id=" + encodeURIComponent(userId)
            })
            .then(res => res.text())
            .then(response => {
                alert(response.trim()); // Show response from PHP
                loadData('users'); // Reload users list
            })
            .catch(error => {
                console.error("Error:", error);
                alert("An error occurred while deleting.");
            });
        }
    }
    </script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
