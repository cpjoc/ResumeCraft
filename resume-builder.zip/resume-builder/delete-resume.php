<?php
session_start();
include 'php/connect.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: php/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];  // Get the user ID from session

// Get the resume_id from the URL
$resume_id = $_GET['resume_id'] ?? null;

// Debugging: check if resume_id is passed
echo "Resume ID from URL: " . htmlspecialchars($resume_id);
echo "<br>User ID from session: " . htmlspecialchars($user_id);

if ($resume_id) {
    // Ensure that resume_id is an integer to prevent SQL injection
    $resume_id = intval($resume_id);

    // Prepare the DELETE statement
    $stmt = $conn->prepare("DELETE FROM resumes WHERE resume_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $resume_id, $user_id);

    // Execute the DELETE query
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            // Successfully deleted the resume
            echo "<script>alert('Resume deleted successfully.'); window.location.href='dashboard.php';</script>";
        } else {
            // If no rows were affected, show an error (resume might not belong to this user)
            echo "<script>alert('No resume found or you do not have permission to delete this resume.'); window.location.href='dashboard.php';</script>";
        }
    } else {
        // If there's a failure in executing the query, show an error message
        echo "<script>alert('Error deleting resume.'); window.location.href='dashboard.php';</script>";
    }

    $stmt->close();
} else {
    // If no resume_id is provided in the URL, show an error
    echo "<script>alert('No resume ID provided.'); window.location.href='dashboard.php';</script>";
}

$conn->close();
?>
