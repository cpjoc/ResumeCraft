<?php
session_start();
include 'php/connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: php/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$resume_id = $_GET['resume_id'] ?? null;

if (!$resume_id) {
    header("Location: dashboard.php");
    exit;
}

// Fetch resume data
$stmt = $conn->prepare("SELECT * FROM resumes WHERE resume_id = ? AND user_id = ?");
$stmt->bind_param("ii", $resume_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$resume = $result->fetch_assoc();
$stmt->close();

if (!$resume) {
    header("Location: dashboard.php");
    exit;
}

// Helper function to avoid undefined key warning
function safe($array, $key, $default = 'N/A')
{
    return htmlspecialchars($array[$key] ?? $default);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"
    integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="style.css" />
    
</head>
<style> 

##objectiveT, #weT {
    width: 500px;
    line-height: 1.6;
    word-wrap: break-word;  /* This will break long words */
    overflow-wrap: break-word;  /* This ensures long words break within their container */
    word-break: break-word;  /* This breaks unbreakable long words */
}


@media print {
  /* Hide elements you don't want to show in the printout */
  .no-print {
    display: none;
  }
}


</style>
<script>
   

</script>
<body class="bg-light">
    
<div class="container mt-5 resume-wrapper">

        <div class="cv" id="cv-template">
            <div class="container">
                <div class="left">
                    <div class="text">
                        <div class="pic">
                            <img id="imgTemplate" src="<?= safe($resume, 'photo', 'path/to/default-image.jpg') ?>"
                                alt="Profile Image" class="img-fluid myimg" />
                        </div>
                        <h2 id="nName"><?= safe($resume, 'full_name') ?></h2>
                        <span id="jJob"><?= safe($resume, 'profession') ?></span>
                    </div>

                    <div class="info">
                        <h3 class="title">Contact Info</h3>
                        <ul class="list-unstyled">
                            <li class="d-flex align-items-center mb-2">
                                <span class="icon me-2"><i class="fa fa-phone"></i></span>
                                <span id="cContact"><?= safe($resume, 'contact') ?></span>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                                <span class="icon me-2"><i class="fa fa-envelope"></i></span>
                                <span id="gGmail"><?= safe($resume, 'gmail') ?></span>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                                <span class="icon me-2"><i class="fa fa-map-marker"></i></span>
                                <span id="fFacebook"><?= safe($resume, 'address') ?></span>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                                <span class="icon me-2"><i class="fa fa-calendar"></i></span>
                                <span
                                    id="lLinkedin"><?= ($resume['birthdate'] ?? '') !== '0000-00-00' ? date('F j, Y', strtotime($resume['birthdate'])) : 'Not Set' ?></span>
                            </li>
                        </ul>
                    </div>

                    <div class="edu">
                        <h3 class="title">Education</h3>
                        <ul id="edu">
                            <?php
                            $education = explode(',', $resume['education'] ?? '');
                            foreach ($education as $edu):
                                if (trim($edu))
                                    echo "<li>" . htmlspecialchars($edu) . "</li>";
                            endforeach;
                            ?>
                        </ul>
                    </div>

                    <div class="lang">
                        <h3 class="title">Languages</h3>
                        <ul id="lan">
                            <?php
                            $languages = explode(',', $resume['languages'] ?? '');
                            foreach ($languages as $lang):
                                if (trim($lang))
                                    echo "<li>" . htmlspecialchars($lang) . "</li>";
                            endforeach;
                            ?>
                        </ul>
                    </div>
                </div>

                <div class="right">
                    <div class="about">
                        <h2>About</h2>
                        <p id="objectiveT"><?= safe($resume, 'summary', 'No summary provided.') ?></p>
                    </div>

                    <div class="exp">
                        <h2>Work Experience</h2>
                        <div class="works">
                            <ul id="weT">
                                <?php
                                $experience = explode(',', $resume['experience'] ?? '');
                                foreach ($experience as $exp):
                                    if (trim($exp))
                                        echo "<li>" . htmlspecialchars($exp) . "</li>";
                                endforeach;
                                ?>
                            </ul>
                        </div>

                        <div class="skills">
                            <h2>Professional Skills</h2>
                            <ul id="skills">
                                <?php
                                $skills = explode(',', $resume['skills'] ?? '');
                                foreach ($skills as $skill):
                                    if (trim($skill))
                                        echo "<li>" . htmlspecialchars($skill) . "</li>";
                                endforeach;
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div id="btnN" class="mt-3 text-center mt-5 my-3">
            <button onclick="window.print()" class="btn btn-primary">Print CV</button>

            </div>
        </div>
    </div>
</body>

</html>
