<?php
session_start();
include 'php/connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: php/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$resume_id = $_POST['resume_id'] ?? null;

// Get form inputs
$full_name = $_POST['full_name'] ?? '';
$profession = $_POST['profession'] ?? '';
$summary = $_POST['summary'] ?? '';
$experience = isset($_POST['experience']) ? implode(', ', $_POST['experience']) : '';
$skills = isset($_POST['skills']) ? implode(', ', $_POST['skills']) : '';
$education = isset($_POST['education']) ? implode(', ', $_POST['education']) : '';
$languages = isset($_POST['languages']) ? implode(', ', $_POST['languages']) : '';
$address = $_POST['address'] ?? '';
$birthdate = $_POST['birthdate'] ?? '';
$contact = $_POST['contact'] ?? '';
$gmail = $_POST['gmail'] ?? '';

// Handle image upload
$photo = '';
if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
    $targetDir = "uploads/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    $photo = $targetDir . basename($_FILES["photo"]["name"]);
    move_uploaded_file($_FILES["photo"]["tmp_name"], $photo);
}

// If updating
if (!empty($resume_id)) {
    $stmt = $conn->prepare("UPDATE resumes SET full_name=?, profession=?, summary=?, skills=?, experience=?, education=?, languages=?, address=?, birthdate=?, contact=?, gmail=?, photo=? WHERE resume_id=? AND user_id=?");
    $stmt->bind_param("ssssssssssssii", $full_name, $profession, $summary, $skills, $experience, $education, $languages, $address, $birthdate, $contact, $gmail, $photo, $resume_id, $user_id);
} else {
    // Insert new
    $stmt = $conn->prepare("INSERT INTO resumes (user_id, full_name, profession, summary, skills, experience, education, languages, address, birthdate, contact, gmail, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssssssss", $user_id, $full_name, $profession, $summary, $skills, $experience, $education, $languages, $address, $birthdate, $contact, $gmail, $photo);
}

// Execute and respond
if ($stmt->execute()) {
    echo "<script>alert('Resume saved successfully!'); window.location.href='dashboard.php';</script>";
} else {
    echo "<script>alert('Error saving resume: " . $stmt->error . "'); window.history.back();</script>";
}

$stmt->close();
$conn->close();
