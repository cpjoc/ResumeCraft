<?php
session_start();
include 'php/connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: php/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Initialize $resume variable to avoid undefined variable warning
$resume = null;

// Check if the user is editing an existing resume
$resume_id = $_GET['resume_id'] ?? null;

if ($resume_id) {
    // Fetch resume data for editing
    $stmt = $conn->prepare("SELECT * FROM resumes WHERE resume_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $resume_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $resume = $result->fetch_assoc();
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Resume Generator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"
        integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css" />
</head>
    <style>
        
    </style>
<body class="bg-light">

    <div class="container mt-5">
        <h2><?= $resume ? "Edit" : "Create" ?> Your Resume</h2>

        <!-- Resume creation/edit form -->
        <form method="POST" action="save-resume.php" enctype="multipart/form-data">
            <?php if ($resume): ?>
                <input type="hidden" name="resume_id" value="<?= $resume['resume_id'] ?>">
            <?php endif; ?>

            <div class="card mx-5 mt-3" id="cv-form">
                <div class="container">
                    <div class="card-header">
                        <h1 class="text-center my-2">Resume Generator</h1>
                    </div>
                    <div class="card-body">
                        <div class="contain">
                            <div class="row">
                                <div class="col-md-6">
                                    <!-- first col -->
                                    <h3>Personal Information</h3>

                                    <div class="form-group">
                                        <label for="nameField">Your Name</label>
                                        <input type="text" id="nameField" name="full_name" placeholder="Enter here"
                                            class="form-control"
                                            value="<?= isset($resume['full_name']) ? htmlspecialchars($resume['full_name']) : '' ?>" />
                                    </div>

                                    <div class="form-group mt-2">
                                        <label for="jobFiled">Your Job title </label>
                                        <input type="text" id="jobFiled" name="profession" placeholder="Enter here"
                                            class="form-control"
                                            value="<?= isset($resume['profession']) ? htmlspecialchars($resume['profession']) : '' ?>" />
                                    </div>

                                    <div class="form-group mt-2">
                                        <label for="contactField">Your Contact</label>
                                        <input type="text" id="contactField" name="contact" placeholder="Enter here"
                                            class="form-control"
                                            value="<?= isset($resume['contact']) ? htmlspecialchars($resume['contact']) : '' ?>" />
                                    </div>

                                    <div class="form-group mt-2">
                                        <label for="gmailFiled">Your gmail</label>
                                        <input id="gmailFiled" name="gmail" placeholder="Enter here"
                                            class="form-control"
                                            value="<?= isset($resume['gmail']) ? htmlspecialchars($resume['gmail']) : '' ?>" />
                                    </div>

                                    <div class="form-group mt-3">
                                        <label for="imgField">Select your photo</label>
                                        <?php if (!empty($resume) && !empty($resume['photo'])): ?>
                                            <img src="<?= htmlspecialchars($resume['photo']) ?>" alt="Resume Photo"
                                                style="width: 100px; height: 100px; object-fit: cover;" />
                                        <?php endif; ?>

                                        <input id="imgField" type="file" name="photo" class="form-control" />
                                    </div>

                                    <p class="text-secondary my-3">Important Links</p>
                                    <div class="form-group mt-2" id="li">
                                        <div class="form-group mt-2">
                                            <label for="fbField">Address </label>
                                            <input type="text" id="fbField" name="address" placeholder="Enter here"
                                                class="form-control"
                                                value="<?= isset($resume['address']) ? htmlspecialchars($resume['address']) : '' ?>" />
                                        </div>

                                        <div class="form-group mt-2">
                                            <label for="linkedField">Birth day</label>
                                            <input type="date" id="linkedField" name="birthdate" class="form-control"
                                                value="<?= isset($resume['birthdate']) ? htmlspecialchars($resume['birthdate']) : '' ?>" />
                                        </div>

                                        <div class="form-group mt-5" id="ed">
                                            <label for="">Education</label>
                                            <?php
                                            $education = isset($resume['education']) ? explode(', ', $resume['education']) : [];
                                            foreach ($education as $edu): ?>
                                                <textarea name="education[]" placeholder="Enter here"
                                                    class="form-control edField" rows="3"><?= $edu ?></textarea>
                                            <?php endforeach; ?>
                                            <div class="container text-center mt-2" id="aqAddButton">
                                                <button type="button" onclick="addNewEdField()"
                                                    class="btn btn-primary btn-sm">Add</button>
                                            </div>
                                        </div>

                                        <div class="form-group mt-2" id="la">
                                            <label for="">Languages</label>
                                            <?php
                                            $languages = isset($resume['languages']) ? explode(', ', $resume['languages']) : [];
                                            foreach ($languages as $lang): ?>
                                                <input name="languages[]" placeholder="Enter here"
                                                    class="form-control laField" value="<?= $lang ?>" />
                                            <?php endforeach; ?>
                                            <div class="container text-center mt-2" id="laAddButton">
                                                <button type="button" onclick="addNewLanField()"
                                                    class="btn btn-primary btn-sm">Add</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <!-- second col -->
                                    <h3>Professional Information</h3>

                                    <div class="form-group mt-2">
                                        <label for="">Objective</label>
                                        <textarea id="objectiveField" name="summary" rows="5" placeholder="Enter here"
                                            class="form-control"><?= isset($resume['summary']) ? htmlspecialchars($resume['summary']) : '' ?></textarea>
                                    </div>

                                    <div class="form-group mt-2" id="we">
                                        <label for="">Work Experience</label>
                                        <?php
                                        $experience = isset($resume['experience']) ? explode(', ', $resume['experience']) : [];
                                        foreach ($experience as $exp): ?>
                                            <textarea name="experience[]" placeholder="Enter Experience"
                                                class="form-control weField" rows="3"><?= $exp ?></textarea>
                                        <?php endforeach; ?>
                                        <div class="container text-center mt-2" id="weAddButton">
                                            <button type="button" onclick="addNewWEField()"
                                                class="btn btn-primary btn-sm">Add</button>
                                        </div>
                                    </div>
                                    <div class="form-group mt-2" id="sk">
                                        <label for="">PROFESSIONAL SKILLS</label>
                                        <?php
                                        $skills = isset($resume['skills']) ? explode(', ', $resume['skills']) : [];
                                        foreach ($skills as $skill): ?>
                                            <input name="skills[]" placeholder="Enter here" class="form-control skField"
                                                value="<?= $skill ?>" />
                                        <?php endforeach; ?>
                                        <div class="container text-center mt-2" id="skAddButton">
                                            <button type="button" onclick="addNewAQField()"
                                                class="btn btn-primary btn-sm">Add</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <script src="script.js"></script>
                    <button type="submit" class="btn btn-primary">💾 Save Resume</button>
                </div>
            </div>
        </form>
    </div>

</body>

</html>