function addNewEdField() {
  const newField = document.createElement('textarea');
  newField.name = 'education[]';
  newField.classList.add('form-control', 'edField');
  newField.rows = 3;
  document.getElementById('ed').appendChild(newField);
}

function addNewLanField() {
  const newField = document.createElement('input');
  newField.name = 'languages[]';
  newField.classList.add('form-control', 'laField');
  document.getElementById('la').appendChild(newField);
}

function addNewWEField() {
  const newField = document.createElement('textarea');
  newField.name = 'experience[]';
  newField.classList.add('form-control', 'weField');
  newField.rows = 3;
  document.getElementById('we').appendChild(newField);
}

function addNewAQField() {
  const newField = document.createElement('input');
  newField.name = 'skills[]';
  newField.classList.add('form-control', 'skField');
  document.getElementById('sk').appendChild(newField);
}
